package report_card;

import java.util.Scanner;

public class MainClass {
	boolean validateInputs(int studentID, int semNumber, int total_subjects, int points_earned) {
		if(studentID/1000<1&&studentID>=10)
			return false;
		else if(semNumber<1&&semNumber>7)
			return false;
		else if(total_subjects<1&&total_subjects>7)
			return false;
		else if(points_earned<1&&points_earned>20)
			return false;
		else
			return true;
	}
	public static void main(String abcd[]) {
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		int id,semester_no,total_subject,points_earned;
		String name,dept_name;
		System.out.println("Enter Student Id:");
		id=sc.nextInt();
		System.out.println("Enter Student name:");
		name=sc1.nextLine();
		System.out.println("Enter department:");
		dept_name=sc1.nextLine();
		System.out.println("Enter Semester number:");
		semester_no=sc.nextInt();
		System.out.println("Enter Total subjects:");
		total_subject=sc.nextInt();
		System.out.println("Enter Points earned:");
		points_earned=sc.nextInt();
		StudentReportCard reportObject =new StudentReportCard(id,name,dept_name,semester_no,total_subject,points_earned);
//		StudentReportCard reportObject1 =new StudentReportCard(1234, "Hariprasath P","CSE",7,10,26);
//		reportObject1.display();
		reportObject.display();
	}
}
