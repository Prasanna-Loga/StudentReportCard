package report_card;

public class student {
	int studentID;
	String studentName;
	String departmentName;
	int semesterNo;
	public student(int studentID, String studentName, String departmentName, int semesterNo) {
		this.studentID = studentID;
		this.studentName = studentName;
		this.departmentName = departmentName;
		this.semesterNo = semesterNo;
	}

	public student() {
		// TODO Auto-generated constructor stub
	}

	public int getSemesterNo() {
		return semesterNo;
	}

	public void setSemesterNo(int semesterNo) {
		this.semesterNo = semesterNo;
	}

	void display()
	{
		System.out.println("Student ID :"+studentID);
		System.out.println("Name of the student :"+studentName);
		System.out.println("Department Name :"+departmentName);
		System.out.println("Semester Number :"+semesterNo);
	}
}
