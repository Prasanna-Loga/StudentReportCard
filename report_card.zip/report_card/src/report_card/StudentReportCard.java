package report_card;

public class StudentReportCard {
	int total_subjects;
	int points_earned;
	float gpa;
	float cgpa;
	student s;
	public StudentReportCard(int studentID, String studentName, String departmentName, int	semesterNo, int total_subjects, int points_earned)
	{
		s=new student(studentID,studentName,departmentName,semesterNo);
		this.total_subjects = total_subjects;
		this.points_earned = points_earned;
	}
	float gpaCalculator() {
		gpa = (float) ((total_subjects * points_earned) / 7.0);
		return gpa;
	
	}
	float cgpaCalculator(float gpa) {
		cgpa =gpa / s.semesterNo;
		return cgpa;
		
	}
	void display(){
		s.display();
		System.out.println("GPA Computed :"+gpaCalculator());
		System.out.println("CGPA Computed :"+cgpaCalculator(gpa));
	}
}
